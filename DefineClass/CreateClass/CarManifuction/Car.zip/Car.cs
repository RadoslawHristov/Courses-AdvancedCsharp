﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarManufacturer
{
    public class Tire
    {
        private int year;
        private double pressure;

        public int Year
        {
            get => this.year;
            set => this.year = value;
        }
        public double Pressure
        {
            get => this.pressure;
            set => this.pressure = value;
        }

        public Tire(int year,double pressure)
        {
            this.year = year;
            this.pressure = pressure;
        }
    }
    public class Engine
    {
        private int horsePower;
        private double cubicCapacity;

        public int Horsepower
        {
            get => this.horsePower;
            set =>this.horsePower=value;
        }

        public double CubicCapacity
        {
            get => this.cubicCapacity;
            set => this.cubicCapacity = value;
        }
        public Engine(int horsePower,double cubicCapacity)
        {
            this.horsePower = horsePower;
            this.cubicCapacity = cubicCapacity;
        }
    }
    public class Car
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public double FuelQuantity { get; set; }
        public double FuelConsumation { get; set; }


        public Car()
        {
            Make = "VW";
            Model = "Golf";
            Year = 2025;
            FuelQuantity = 200;
            FuelConsumation = 10;
        }
        
        public Car(string make, string model, int year)
        :this()
        {
            this.Make = make;
            this.Model = model;
            this.Year = year;
        }

        public Car(string make, string model, int year, double fuelQuantity, double fuelConsumation)
            : this(make, model, year)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumation = fuelConsumation;
        }

        public Car(string make,string model,int year,double fuelQuantity,double fuelConsumation,Engine engine,Tire[] tires)
        :this(make,model,year,fuelQuantity,fuelConsumation)
        {
            this.engine = engine;
            this. = tires;
        }
    }
}
